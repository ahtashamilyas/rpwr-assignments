#!/usr/bin/env python3

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        # Start turtlesim node
        Node(
            package='turtlesim',
            executable='turtlesim_node',
            name='sim'
        ),
        
        # Start turtle1 tf2 broadcaster
        Node(
            package='turtle_tf2_py',
            executable='turtle_tf2_broadcaster',
            name='broadcaster1',
            parameters=[
                {'turtlename': 'turtle1'}
            ]
        ),
        
        # Start turtle2 tf2 broadcaster
        Node(
            package='turtle_tf2_py',
            executable='turtle_tf2_broadcaster',
            name='broadcaster2',
            parameters=[
                {'turtlename': 'turtle2'}
            ]
        ),
        
        # Start turtle3 tf2 broadcaster
        Node(
            package='turtle_tf2_py',
            executable='turtle_tf2_broadcaster',
            name='broadcaster3',
            parameters=[
                {'turtlename': 'turtle3'}
            ]
        ),
        
        # Start turtle4 tf2 broadcaster
        Node(
            package='turtle_tf2_py',
            executable='turtle_tf2_broadcaster',
            name='broadcaster4',
            parameters=[
                {'turtlename': 'turtle4'}
            ]
        ),
        
        # Turtle2 follows turtle1
        Node(
            package='turtle_party',
            executable='follow',
            name='follower2',
            parameters=[
                {'target_frame': 'turtle1'},
                {'turtle_name': 'turtle2'}
            ]
        ),
        
        # Turtle3 follows turtle2
        Node(
            package='turtle_party',
            executable='follow',
            name='follower3',
            parameters=[
                {'target_frame': 'turtle2'},
                {'turtle_name': 'turtle3'}
            ]
        ),
        
        # Turtle4 follows turtle3
        Node(
            package='turtle_party',
            executable='follow',
            name='follower4',
            parameters=[
                {'target_frame': 'turtle3'},
                {'turtle_name': 'turtle4'}
            ]
        ),
        
        # Keyboard teleop for turtle1
        Node(
            package='turtlesim',
            executable='turtle_teleop_key',
            name='teleop',
            prefix='xterm -e',
            output='screen'
        ),
    ])