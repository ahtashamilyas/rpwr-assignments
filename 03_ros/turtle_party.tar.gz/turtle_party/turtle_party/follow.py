#!/usr/bin/env python3

import math
import rclpy
from rclpy.node import Node
from tf2_ros import TransformException
from tf2_ros.buffer import Buffer
from tf2_ros.transform_listener import TransformListener
from geometry_msgs.msg import Twist
from turtlesim.srv import Spawn


class TurtleFollower(Node):

    def __init__(self):
        super().__init__('turtle_follower')
        
        # Declare parameters
        self.declare_parameter('target_frame', 'turtle1')
        self.declare_parameter('turtle_name', 'turtle2')
        
        # Get parameters
        self.target_frame = self.get_parameter('target_frame').get_parameter_value().string_value
        self.turtle_name = self.get_parameter('turtle_name').get_parameter_value().string_value
        
        # TF2 setup
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
        # Publisher for turtle velocity commands
        self.publisher = self.create_publisher(
            Twist, 
            f'/{self.turtle_name}/cmd_vel', 
            1
        )
        
        # Timer for control loop
        self.timer = self.create_timer(0.1, self.on_timer)
        
        # Spawn the turtle
        self.spawn_turtle()

    def spawn_turtle(self):
        """Spawn a new turtle at a random position"""
        spawn_client = self.create_client(Spawn, '/spawn')
        
        while not spawn_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Spawn service not available, waiting...')
        
        request = Spawn.Request()
        request.name = self.turtle_name
        request.x = 4.0
        request.y = 2.0
        request.theta = 0.0
        
        future = spawn_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        
        if future.result() is not None:
            self.get_logger().info(f'Successfully spawned {self.turtle_name}')
        else:
            self.get_logger().error(f'Failed to spawn {self.turtle_name}')

    def on_timer(self):
        """Timer callback to control turtle following behavior"""
        try:
            # Look up the transformation from turtle_name to target_frame
            transform = self.tf_buffer.lookup_transform(
                self.turtle_name,
                self.target_frame,
                rclpy.time.Time()
            )
        except TransformException as ex:
            self.get_logger().info(f'Could not transform {self.turtle_name} to {self.target_frame}: {ex}')
            return

        # Create velocity command
        msg = Twist()
        
        # Calculate distance and angle to target
        distance = math.sqrt(transform.transform.translation.x ** 2 + 
                           transform.transform.translation.y ** 2)
        angle = math.atan2(transform.transform.translation.y,
                          transform.transform.translation.x)
        
        # Control gains
        linear_gain = 1.0
        angular_gain = 6.0
        
        # Set velocity commands
        msg.linear.x = linear_gain * distance
        msg.angular.z = angular_gain * angle
        
        # Publish the velocity command
        self.publisher.publish(msg)


def main():
    rclpy.init()
    node = TurtleFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()