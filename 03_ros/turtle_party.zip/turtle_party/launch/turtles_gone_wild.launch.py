#!/usr/bin/env python3

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    # Declare the launch argument
    amount_arg = DeclareLaunchArgument(
        'amount',
        default_value='3',
        description='Number of turtles to spawn'
    )
    
    # Create the turtlesim node
    turtlesim_node = Node(
        package='turtlesim',
        executable='turtlesim_node',
        name='turtlesim'
    )
    
    # Create the turtle spawner node
    spawner_node = Node(
        package='turtle_party',
        executable='turtle_spawner',
        name='turtle_spawner',
        parameters=[{'amount': LaunchConfiguration('amount')}]
    )
    
    # Create the broadcaster for turtle1
    broadcaster1_node = Node(
        package='turtle_party',
        executable='turtle_broadcaster',
        name='broadcaster1',
        parameters=[{'turtle': 'turtle1'}]
    )
    
    # Create listener and broadcaster nodes for other turtles
    nodes = [turtlesim_node, spawner_node, broadcaster1_node]
    
    for i in range(2, 10):  # Support up to 10 turtles
        broadcaster_node = Node(
            package='turtle_party',
            executable='turtle_broadcaster',
            name=f'broadcaster{i}',
            parameters=[{'turtle': f'turtle{i}'}],
            condition=LaunchConfiguration('amount').perform(context=None) >= str(i)
        )
        
        listener_node = Node(
            package='turtle_party',
            executable='turtle_listener',
            name=f'listener{i}',
            parameters=[
                {'turtle': f'turtle{i}', 
                 'target_turtle': f'turtle{i-1}'}
            ],
            condition=LaunchConfiguration('amount').perform(context=None) >= str(i)
        )
        
        nodes.append(broadcaster_node)
        nodes.append(listener_node)
    
    return LaunchDescription([amount_arg] + nodes)