#!/usr/bin/env python3

import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TransformStamped
from turtlesim.msg import Pose
from tf2_ros import TransformBroadcaster


class TurtleBroadcaster(Node):
    def __init__(self):
        super().__init__('turtle_broadcaster')
        
        # Declare and get parameters
        self.declare_parameter('turtle', 'turtle1')
        self.turtle_name = self.get_parameter('turtle').get_parameter_value().string_value
        
        # Create a TransformBroadcaster
        self.tf_broadcaster = TransformBroadcaster(self)
        
        # Subscribe to the turtle pose
        self.subscription = self.create_subscription(
            Pose,
            f'/{self.turtle_name}/pose',
            self.handle_turtle_pose,
            10)
        
        self.get_logger().info(f'Broadcasting transforms for {self.turtle_name}')

    def handle_turtle_pose(self, msg):
        t = TransformStamped()
        
        # Read message content and assign it to the transform
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'world'
        t.child_frame_id = self.turtle_name
        
        # Turtle only moves in 2D, z is 0
        t.transform.translation.x = msg.x
        t.transform.translation.y = msg.y
        t.transform.translation.z = 0.0
        
        # Turtle only rotates around the z-axis
        q_x = 0.0
        q_y = 0.0
        q_z = math.sin(msg.theta / 2)
        q_w = math.cos(msg.theta / 2)
        t.transform.rotation.x = q_x
        t.transform.rotation.y = q_y
        t.transform.rotation.z = q_z
        t.transform.rotation.w = q_w
        
        # Send the transform
        self.tf_broadcaster.sendTransform(t)


def main(args=None):
    rclpy.init(args=args)
    node = TurtleBroadcaster()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()