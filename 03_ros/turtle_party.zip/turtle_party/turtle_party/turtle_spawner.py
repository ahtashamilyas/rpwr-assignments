#!/usr/bin/env python3

import math
import random
import rclpy
from rclpy.node import Node
from turtlesim.srv import Spawn, Kill
from geometry_msgs.msg import Twist
from tf2_ros import StaticTransformBroadcaster
from geometry_msgs.msg import TransformStamped


class TurtleSpawner(Node):
    def __init__(self):
        super().__init__('turtle_spawner')
        
        # Declare and get parameters
        self.declare_parameter('amount', 3)
        self.amount = self.get_parameter('amount').get_parameter_value().integer_value
        
        # Create a static transform broadcaster for centering the grid
        self.static_broadcaster = StaticTransformBroadcaster(self)
        
        # Create a publisher for the first turtle
        self.publisher = self.create_publisher(
            Twist,
            '/turtle1/cmd_vel',
            10)
        
        # Create clients for the spawn and kill services
        self.spawn_client = self.create_client(Spawn, 'spawn')
        self.kill_client = self.create_client(Kill, 'kill')
        
        # Wait for the services to be available
        while not self.spawn_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Spawn service not available, waiting...')
        while not self.kill_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Kill service not available, waiting...')
        
        # Spawn turtles
        self.spawn_turtles()
        
        # Broadcast static transform to center grid
        self.broadcast_static_transform()
        
        # Create a timer for random movement of turtle1
        self.timer = self.create_timer(3.0, self.move_random)
        
        self.get_logger().info(f'Spawned {self.amount} turtles')

    def spawn_turtles(self):
        # We already have turtle1, so start from 2
        for i in range(2, self.amount + 1):
            # Create a request
            request = Spawn.Request()
            request.x = random.uniform(1.0, 10.0)
            request.y = random.uniform(1.0, 10.0)
            request.theta = random.uniform(0, 2 * math.pi)
            request.name = f'turtle{i}'
            
            # Call the service
            future = self.spawn_client.call_async(request)
            # We don't need to wait for the result here since we're setting up everything
            
            self.get_logger().info(f'Spawned turtle{i}')

    def broadcast_static_transform(self):
        # Create a static transform to center the grid
        t = TransformStamped()
        
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'map'
        t.child_frame_id = 'world'
        
        # Center the grid (adjust these values as needed)
        t.transform.translation.x = 5.5
        t.transform.translation.y = 5.5
        t.transform.translation.z = 0.0
        
        # No rotation
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = 0.0
        t.transform.rotation.w = 1.0
        
        # Send the transform
        self.static_broadcaster.sendTransform(t)

    def move_random(self):
        # Create a random movement for turtle1
        msg = Twist()
        
        # Generate random linear and angular velocities
        msg.linear.x = random.uniform(0.5, 2.0)
        msg.angular.z = random.uniform(-2.0, 2.0)
        
        # Publish the message
        self.publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = TurtleSpawner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()