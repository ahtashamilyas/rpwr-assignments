#!/usr/bin/env python3

import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from tf2_ros import Buffer, TransformListener
from tf2_ros.exceptions import LookupException, ConnectivityException, ExtrapolationException


class TurtleListener(Node):
    def __init__(self):
        super().__init__('turtle_listener')
        
        # Declare and get parameters
        self.declare_parameter('turtle', 'turtle2')
        self.declare_parameter('target_turtle', 'turtle1')
        
        self.turtle_name = self.get_parameter('turtle').get_parameter_value().string_value
        self.target_frame = self.get_parameter('target_turtle').get_parameter_value().string_value
        
        # Create a tf2 buffer and listener
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
        # Create a publisher to control the turtle
        self.publisher = self.create_publisher(
            Twist,
            f'/{self.turtle_name}/cmd_vel',
            10)
        
        # Call the control turtle function at a rate of 10 Hz
        self.timer = self.create_timer(0.1, self.control_turtle)
        
        self.get_logger().info(f'{self.turtle_name} is following {self.target_frame}')

    def control_turtle(self):
        try:
            # Look up for the transformation between target_frame and turtle_name
            trans = self.tf_buffer.lookup_transform(
                self.turtle_name,
                self.target_frame,
                rclpy.time.Time())
                
        except (LookupException, ConnectivityException, ExtrapolationException) as e:
            self.get_logger().warning(f'Transform error: {e}')
            return
            
        msg = Twist()
        
        # Calculate distance and angular difference
        x = trans.transform.translation.x
        y = trans.transform.translation.y
        angular = math.atan2(y, x)
        linear = math.sqrt(x ** 2 + y ** 2)
        
        # Set control commands
        msg.linear.x = 0.5 * linear
        msg.angular.z = 4.0 * angular
        
        # Publish control commands
        self.publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = TurtleListener()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()